<h1>رسالة من {{ $name }}</h1>
<p>{{ $message_txt }}</p>