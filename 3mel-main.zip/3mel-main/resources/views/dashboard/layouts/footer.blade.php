        
        
        <script src="{{ asset('dashboard_res/js/jquery-2.1.4.js') }}"></script>
		<script src="{{ asset('dashboard_res/js/bootstrap.min.js') }}"></script>
		<script src="{{ asset('dashboard_res/js/all.js') }}"></script>
		<script src="{{ asset('dashboard_res/js/plugin.js') }}"></script>
		<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
		<script src="{{ asset('/js/custom.js') }}"></script>
	</body>
</html>